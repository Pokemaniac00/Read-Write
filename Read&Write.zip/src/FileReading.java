import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * This class' purpose is to read messages from files.
 * 
 * @author  Aric Flor
 * @version 2.10.19
 */
public class FileReading
{
  public void read(File file)
  {
    try
    {
      Scanner input;
      input = new Scanner(file);
      
      while(input.hasNextLine())
      {
        System.out.println(input.nextLine());
      }
      
      input.close();
    } // end try
    catch (FileNotFoundException fnfe)
    {
      fnfe.printStackTrace();
    } // end catch
  } // end method
  
  public void read(String fileName)
  {
    File file;
    file = new File(fileName);
    
    read(file);
  } // end method
  
  public void readInReverse(File file)
  {
    try
    {
      String reverse;
      Scanner input;
      
      input = new Scanner(file);
      reverse = "";
      
      while(input.hasNextLine())
      {
        String nextLine;
        nextLine = input.nextLine();
         
        for(int i = nextLine.length() - 1; i >= 0; i--)
        {
          reverse += nextLine.charAt(i);
        } // end for
        System.out.println(reverse);
      } // end while
      
      input.close();
    }
    catch (FileNotFoundException fnfe)
    {
      fnfe.printStackTrace();
    } // end method
  } // end method
  
  public void readInReverse(String fileName)
  {
    File file;
    file = new File(fileName);
    
    readInReverse(file);
  } // end method
} // end class
