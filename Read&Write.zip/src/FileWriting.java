import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * This class' purpose is to be able to write messages to files.
 * 
 * @author  Aric Flor
 * @version 2.10.19
 */
public class FileWriting
{
  /**
   * Writes a message to a file.
   * 
   * @param message     A message to be written.
   * @param file        File to be written to.
   */
  public void write(String message, File file)
  {
    try
    {
      if (!file.exists())
      {
        file.createNewFile();
      } // end if

      PrintWriter writer;
      writer = new PrintWriter(file);
      writer.print(message);
      writer.close();
    } // end try
    catch (FileNotFoundException fnfe)
    {
      fnfe.printStackTrace();
    } // end catch
    catch (IOException ioe)
    {
      ioe.printStackTrace();
    } // end catch
  } // end method

  /**
   * Writes a message to a file.
   * 
   * @param message       A message to be written.
   * @param fileName      File name associated with file.
   */
  public void write(String message, String fileName)
  {
    File file;
    file = new File(fileName);

    write(message, file);
  } // end method
} // end class
