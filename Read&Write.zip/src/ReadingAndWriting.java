import java.io.File;

/**
 * This class' purpose is to display a string message in reverse.
 * 
 * @author  Aric Flor
 * @version 2.10.19
 */
public class ReadingAndWriting
{

  /**
   * This is the entry point of reading and writing files.
   * 
   * @param args    String arguments.
   */
  public static void main(String[] args)
  {
    FileWriting f;
    FileReading r;
    f = new FileWriting();
    r = new FileReading();
    
    f.write("This is a reversible String.", new File("test.txt"));
    r.read("test.txt");
    r.readInReverse("test.txt");
  } // end main

} // end class
